void Draw_Song(void)
{

                        //draw song menu**********************************************************
                    if(MENUSWITCH==1)
                    {//tasks to do only when switching tab
                        TEMPO_FIX=60;
                        //tab section*/*/*****************************************************
                        ClearText(0);ClearText(2);
                        tab(1,0,1);tab(5,0,1);tab(9,0,1);tab(13,0,0);tab(17,0,1);tab(21,0,1);tab(25,0,1);
                        PutText( 1,0x01,"patt",1);
                        PutText( 5,0x01,"samp",1);
                        PutText( 9,0x01,"inst",1);
                        PutText(13,0x01,"SONG",0);
                        PutText(17,0x01,"live",1);
                        PutText(21,0x01,"file",1);
                        PutText(25,0x01,"cfg",1);
                        //GFX section*/*/*****************************************************
                        Window(0,2,20,19,1);
                        PutText( 1,0x03,"SONG LENGHT",0);
                        PutText( 1,0x04,"JUMP START",0);
                    }
                    Box(15,3,4,SNG_LEN+1,0,0);
                    Box(15,4,4,SNG_JMP,0,0);
                    //songlist code***********************************************************
                    u8 c,co;
                    for(co=0;co<18;co++)
                    {
                        if(co+SNG_LISTOFFSET<1025)
                        {
                            if(co+SNG_LISTOFFSET!=(SNG_POS))
                                {
                                    Box(25,2+co,4,SONG[co+SNG_LISTOFFSET].index,0,1);
                                }
                                else
                                {
                                    Box(25,2+co,4,SONG[co+SNG_LISTOFFSET].index,1,1);
                                }
                                if(co!=(CURSNG))
                                {
                                    Box(21,2+co,4,co+SNG_LISTOFFSET,0,0);
                                }
                                else
                                {
                                    Box(21,2+co,4,co+SNG_LISTOFFSET,1,0);
                                }
                            }
                        }
                        for(c=0;c<4;c++)
                        {
                            ham_SetMapTile(2,21+c,2+CURSNG,181);
                            if((SNG_LISTOFFSET)<=SNG_POS)ham_SetMapTile(2,25+c,2+SNG_POS,183);
                        }
                        itoa(CURSNG,(char*)value);
                        PutText(5,5,(char*)value,0);
                        itoa(SNG_POS,(char*)value);
                        PutText(5,6,(char*)value,0);
                        itoa(SNG_LISTOFFSET,(char*)value);
                        PutText(5,7,(char*)value,0);
                        itoa(CURSNG+SNG_LISTOFFSET,(char*)value);
                        PutText(6,8,(char*)value,0);
}


#ifdef MIKE_ADDITIONS

void save_song(void)
{
    int i;
    char tag[5];

    tag[0] = 'A';
    tag[1] = 'A';
    tag[2] = 'A';
    tag[3] = ' ';
    tag[4] = 0;
    ham_SaveRawToRAM(tag, &SONG, sizeof SONG);

    tag[0] = 'A';
    tag[1] = 'A';
    tag[2] = 'B';
    tag[4] = 0;
    ham_SaveRawToRAM(tag, &pat_hdr, sizeof pat_hdr);

    tag[0] = 'A';
    tag[1] = 'A';
    tag[2] = 'C';
    tag[3] = 1;
    tag[4] = 0;
    for(i=0; i<pat_hdr.max_pat; i++) {

        //dibujar ventanita salvando
        ham_SaveRawToRAM(tag, &(PATTERN[i]), sizeof(struct tracker_pattern));


        tag[3]++;
    }
}

void load_song(void)
{
    int i;
    char tag[5];

    ham_LoadRawFromRAM("AAA ", &SONG);
    ham_LoadRawFromRAM("AAB ", &pat_hdr);

    tag[0] = 'A';
    tag[1] = 'A';
    tag[2] = 'C';
    tag[3] = 1;
    tag[4] = 0;
    u32 r;
    for(i=0; i<pat_hdr.max_pat; i++) {
        //dibujar ventanita cargando =)
        r=ham_LoadRawFromRAM(tag, &(PATTERN[i]));
        tag[3]++;
    }



/*            if(r==0xffffffff)
        {
            //ham_ResetRAM();
            u16 t=0;
            bool st=0;
            while(!F_CTRLINPUT_A_PRESSED)
            {
                t++;
                if(t>1000)
                {
                    st^=1;
                    t=0;
                }
                if(st)PutText(4,9,"SAVE DATA IS CORRUPT!!",1);
                else
                {
                    t++;
                    PutText(4,9,"                      ",1);
                }
            }
        }*/

}

#endif

