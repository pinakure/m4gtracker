struct tracker_position
{
       u8 note[16];
       u8 ins[16];
       u8 vol[16];
       u8 fxc[16];
       u8 fxp[16];
};
struct tracker_pattern
{
        struct tracker_position CHANNEL[6];
};//PATTERN[255];
/// -- TODO --
struct pattern_order
{
        u8 index;
};

#ifdef MIKE_ADDITIONS
    typedef struct {
        u8 max_pat;
    } pat_header_t;
#endif
struct pattern_order *SONG;
struct tracker_pattern *PATTERN;


#ifdef MIKE_ADDITIONS
    pat_header_t pat_hdr;
#endif


struct Input_Type
{
    bool A;
    bool B;
    bool L;
    bool R;
    bool s;
    bool S;
    bool u;
    bool d;
    bool l;
    bool r;
}INPUT[3];
