//**************************************************************************************//
void GetInput_Tracker(void)
{//tracker input controller
    if(KEYPAD_PRESS.B)
    {
        switch(CURSOR)
        {
            case 0:case 10:case 20:
                if(KEYPAD.A)
                {
                    KEYVALUE=PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].note[PAT_POS];
                    PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].note[PAT_POS]=101;
                    REDRAWTRACKER=1;
                }
                break;
            case 1:case 11:case 21:
                if(KEYPAD.A)
                {
                    INSVALUE=PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].ins[PAT_POS];
                    PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].ins[PAT_POS]=0;
                    REDRAWTRACKER=1;
                }
                break;
        }
    }

    if(KEYPAD_PRESS.A)
    {
        switch(CURSOR)
        {
            case 0:case 10:case 20:
                while(!REDRAWTRACKER)
                {
                    if((KEYPAD.u)||(KEYPAD_PRESS.u)){KEYVALUE+=12;if(KEYVALUE>99){KEYVALUE=98;};KEYPAD_RESET;REDRAWTRACKER=1;}
                    if((KEYPAD.d)||(KEYPAD_PRESS.d)){KEYVALUE-=12;if(KEYVALUE>128){KEYVALUE=0;};KEYPAD_RESET;REDRAWTRACKER=1;}
                    if((KEYPAD.l)||(KEYPAD_PRESS.l)){if(KEYVALUE>0)KEYVALUE--;KEYPAD_RESET;REDRAWTRACKER=1;}
                    if((KEYPAD.r)||(KEYPAD_PRESS.r)){if(KEYVALUE<98)KEYVALUE++;KEYPAD_RESET;REDRAWTRACKER=1;}
                    if(PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].note[PAT_POS]<100)
                    {
                        PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].note[PAT_POS]=KEYVALUE;
                        REDRAWTRACKER=1;
                    }
                    else
                    {
                        PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].note[PAT_POS]=1;
                        REDRAWTRACKER=1;
                    }
                }
                KEYPAD_PRESS_RESET;
                break;
            case 1:case 11:case 21:case 2:case 12:case 22:
                if((KEYPAD.u)||(KEYPAD_PRESS.u)){KEYPAD_RESET;INSVALUE+=16;REDRAWTRACKER=1;}
                if((KEYPAD.d)||(KEYPAD_PRESS.d)){KEYPAD_RESET;INSVALUE-=16;REDRAWTRACKER=1;}
                if((KEYPAD.l)||(KEYPAD_PRESS.l)){KEYPAD_RESET;INSVALUE--;REDRAWTRACKER=1;}
                if((KEYPAD.r)||(KEYPAD_PRESS.r)){KEYPAD_RESET;INSVALUE++;REDRAWTRACKER=1;}
                PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].ins[PAT_POS]=INSVALUE;
                KEYPAD_PRESS_RESET;
                break;
            case 3:case 13:case 23:case 4:case 14:case 24:
                if(SPECIALCOLUMN)
                {//sfx column     *
                    if((KEYPAD.u)||(KEYPAD_PRESS.u)){KEYPAD_RESET;SFXVALUE+=16;REDRAWTRACKER=1;}
                    if((KEYPAD.d)||(KEYPAD_PRESS.d)){KEYPAD_RESET;SFXVALUE-=16;REDRAWTRACKER=1;}
                    if((KEYPAD.l)||(KEYPAD_PRESS.l)){KEYPAD_RESET;SFXVALUE--;REDRAWTRACKER=1;}
                    if((KEYPAD.r)||(KEYPAD_PRESS.r)){KEYPAD_RESET;SFXVALUE++;REDRAWTRACKER=1;}
                    PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].fxc[PAT_POS]=SFXVALUE;
                }    
                else
                {//volume column    *
                    if((KEYPAD.u)||(KEYPAD_PRESS.u)){KEYPAD_RESET;VOLVALUE+=16;REDRAWTRACKER=1;}
                    if((KEYPAD.d)||(KEYPAD_PRESS.d)){KEYPAD_RESET;VOLVALUE-=16;REDRAWTRACKER=1;}
                    if((KEYPAD.l)||(KEYPAD_PRESS.l)){KEYPAD_RESET;VOLVALUE--;REDRAWTRACKER=1;}
                    if((KEYPAD.r)||(KEYPAD_PRESS.r)){KEYPAD_RESET;VOLVALUE++;REDRAWTRACKER=1;}
                    PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].vol[PAT_POS]=VOLVALUE;
                }
                KEYPAD_PRESS_RESET;
                break;
            case 5:case 15:case 25:case 6:case 16:case 26:
            {//parameter column   *
                if((KEYPAD.u)||(KEYPAD_PRESS.u)){KEYPAD_RESET;PARVALUE+=16;REDRAWTRACKER=1;}
                if((KEYPAD.d)||(KEYPAD_PRESS.d)){KEYPAD_RESET;PARVALUE-=16;REDRAWTRACKER=1;}
                if((KEYPAD.l)||(KEYPAD_PRESS.l)){KEYPAD_RESET;PARVALUE--;REDRAWTRACKER=1;}
                if((KEYPAD.r)||(KEYPAD_PRESS.r)){KEYPAD_RESET;PARVALUE++;REDRAWTRACKER=1;}
                PATTERN[SONG[SNG_POS].index].CHANNEL[CHANNEL].fxp[PAT_POS]=PARVALUE;
                KEYPAD_PRESS_RESET;
                break;
            }
        }
        return;
    }
    else
    if(KEYPAD.u)
    {
        switch(PAT_POS)
        {
            case 0:
                switch(P_WRAP)
                {
                    case 1:
                        PAT_POS=15;
                        SNG_POS--;
                        REDRAWTRACKER=1;
                        REDRAWTRACKERCURSOR=1;
                        REDRAWTRACKERBG=1;
                        break;
                    case 0:
                        PAT_POS=15;
                        REDRAWTRACKERCURSOR=1;
                        REDRAWTRACKERBG=1;
                        break;
                }
                break;
            default:
                PAT_POS--;
                REDRAWTRACKERCURSOR=1;
                REDRAWTRACKERBG=1;
                break;
        }
    }
    else
    if(KEYPAD.d)
    {
        switch(PAT_POS)
        {
            case 15:
                switch(P_WRAP)
                {
                    case 1:
                        PAT_POS=0;
                        SNG_POS++;
                        if(SNG_POS>SNG_LEN)SNG_POS=SNG_JMP;
                        REDRAWTRACKER=1;
                        REDRAWTRACKERCURSOR=1;
                        break;
                    case 0:
                        PAT_POS=0;
                        REDRAWTRACKER=1;
                        REDRAWTRACKERCURSOR=1;
                        break;
                }
                break;
            default:
                PAT_POS++;
                REDRAWTRACKERCURSOR=1;
                REDRAWTRACKERBG=1;
                break;
        }
        
    }
    if(KEYPAD.l)
    {
        if(!T_WRAP){if(CURSOR>0)CURSOR--;}else CURSOR--;
        REDRAWTRACKERCURSOR=1;
    }
    if(KEYPAD.r)
    {
        if(!T_WRAP){if(CURSOR<26)CURSOR++;}else CURSOR++;
        REDRAWTRACKERCURSOR=1;
    }
    KEYPAD_RESET;
}
//**************************************************************************************//
void GetInput(void)
{
    if(KEY_TIMER==KEY_RATE)
    {
        KEY_DISPONIBLE=TRUE;
    }else
    {
        KEY_TIMER++;
    }
    KEYPAD_RESET;
    //This section checks if a button is released, then we have the input again.
    ham_UpdatePad();
    //This section checks if a button is pushed, if we have the input, then enables the
    // flag of the input (KEYPAD).
    while(KEY_DISPONIBLE==TRUE)
    {
        KEYPAD_PRESS_RESET;
        if(F_CTRLINPUT_A_PRESSED){KEYPAD_PRESS.A=TRUE;KEY_TIMER=0;}
        if(F_CTRLINPUT_B_PRESSED){KEYPAD_PRESS.B=TRUE;KEY_TIMER=0;}
        if(F_CTRLINPUT_L_PRESSED){KEYPAD_PRESS.L=TRUE;KEY_TIMER=0;}
        if(F_CTRLINPUT_R_PRESSED){KEYPAD_PRESS.R=TRUE;KEY_TIMER=0;}
        if(F_CTRLINPUT_SELECT_PRESSED){KEYPAD_PRESS.s=TRUE;KEY_TIMER=0;}
        if(F_CTRLINPUT_UP_PRESSED){KEYPAD_PRESS.u=TRUE;KEY_TIMER=0;KEY_DISPONIBLE=FALSE;}
        if(F_CTRLINPUT_DOWN_PRESSED){KEYPAD_PRESS.d=TRUE;KEY_TIMER=0;KEY_DISPONIBLE=FALSE;}
        if(F_CTRLINPUT_LEFT_PRESSED){KEYPAD_PRESS.l=TRUE;KEY_TIMER=0;KEY_DISPONIBLE=FALSE;}
        if(F_CTRLINPUT_RIGHT_PRESSED){KEYPAD_PRESS.r=TRUE;KEY_TIMER=0;KEY_DISPONIBLE=FALSE;}
        if(F_CTRLINPUT_START_PRESSED){KEYPAD_PRESS.S=TRUE;KEY_TIMER=0;KEY_DISPONIBLE=FALSE;}
        KEY_DISPONIBLE=FALSE;
        KEY_TIMER=0;
    }
    if(Pad.Pressed.A){KEYPAD.A=TRUE;}else{KEYPAD.A=FALSE;}
    if(Pad.Pressed.B){KEYPAD.B=TRUE;}else{KEYPAD.B=FALSE;}
    if(Pad.Pressed.L){KEYPAD.L=TRUE;}else{KEYPAD.L=FALSE;}
    if(Pad.Pressed.R){KEYPAD.R=TRUE;}else{KEYPAD.R=FALSE;}
    if(Pad.Pressed.Left){KEYPAD.l=TRUE;}else{KEYPAD.l=FALSE;}
    if(Pad.Pressed.Right){KEYPAD.r=TRUE;}else{KEYPAD.r=FALSE;}
    if(Pad.Pressed.Up){KEYPAD.u=TRUE;}else{KEYPAD.u=FALSE;}
    if(Pad.Pressed.Down){KEYPAD.d=TRUE;}else{KEYPAD.d=FALSE;;}
    if(Pad.Pressed.Start){KEYPAD.S=TRUE;}else{KEYPAD.S=FALSE;}
    if(Pad.Pressed.Select){KEYPAD.s=TRUE;}else{KEYPAD.s=FALSE;}
}
//**************************************************************************************//
void GetInput_General(void)
{
    if(Pad.Pressed.R)
        {
            MENUSWITCH=1;
            MENU++;
            KEYPAD_RESET;
        }
        else
        if(Pad.Pressed.L)
        {
            MENUSWITCH=1;
            MENU--;
            KEYPAD_RESET;
        }
        if(F_CTRLINPUT_L_PRESSED)
        {
            if(Pad.Pressed.Down)
            {
                SNG_POS++;
                if(SNG_POS>SNG_LEN)SNG_POS=SNG_JMP;
                REDRAWTRACKER=1;
                KEYPAD_RESET;
            }
            if(Pad.Pressed.Up)
            {
                if(SNG_POS>0)SNG_POS--;
                REDRAWTRACKER=1;
                KEYPAD_RESET;
            }
            if(Pad.Pressed.Left)
            {

            }
            
        }

        if(Pad.Pressed.Select)
        {

            if(F_CTRLINPUT_B_PRESSED)
            {
                if(F_CTRLINPUT_L_PRESSED)RESET=1;
            }
            else
            {
                SPECIALCOLUMN^=1;
                KEYPAD_RESET;
            }
        }
        if(Pad.Pressed.Start)
        {
            switch(F_CTRLINPUT_SELECT_PRESSED)
            {
                case 0://play pattern
                    PLAYING^=1;
                    PLAYSONG=0;
                    KEYPAD_RESET;
                    break;
                case 1://play song
                    PLAYSONG=1;
                    PLAYING=1;
                    PAT_POS=0;
                    SNG_POS=0; //<<-----------
                    KEYPAD_RESET;
                    break;
            }
        }
}
//**************************************************************************************//
void GetInput_Song(void)
{
    //************************************************************************
    //CONTROL THE INPUT                                                     *-
    //************************************************************************
    if(KEYPAD.u)
    {
        //TOOD SWITCH HERE///////-----------------<<--------<<-------------
        if(CURSNG+SNG_LISTOFFSET>SNG_LISTOFFSET)
        {
            CURSNG--;
        }
        else
        {
            if(SNG_LISTOFFSET==0)
            {
                ;//do nothing
            }
            else
            {
                SNG_LISTOFFSET-=18;
                CURSNG=17;
            }
        }
    }
    if(KEYPAD.B)
    {
        if(KEYPAD.A)
        {//copy song list value
            SNG_LISTVALUE=CURSNG+SNG_LISTOFFSET;
        }
        else SNG_POS=CURSNG+SNG_LISTOFFSET;
    }

    if(KEYPAD.l)
    {
        if(SONG[CURSNG+SNG_LISTOFFSET].index>0)SONG[CURSNG+SNG_LISTOFFSET].index--;
    }

    if(KEYPAD.r)
    {
        if(SONG[CURSNG+SNG_LISTOFFSET].index<255)SONG[CURSNG+SNG_LISTOFFSET].index++;
    }

    if(KEYPAD.d)
    {
        if(CURSNG+SNG_LISTOFFSET<SNG_LISTOFFSET+17)
        {
            CURSNG++;
        }
        else
        {
            if(SNG_LISTOFFSET==1008)
            {
                ;//do nothing
            }
            else
            {
                SNG_LISTOFFSET+=18;
                CURSNG=0;
            }
        }
    }
    KEYPAD_RESET;
}

void GetInput_Config(void)
{
                    if(Pad.Pressed.Up)
                        {
                            PutText( 2 ,3+CFGCUR," ",0);
                            CFGCUR--;
                            if(CFGCUR==255)CFGCUR=15;
                        }
                        if(Pad.Pressed.Down)
                        {
                            PutText( 2 ,3+CFGCUR," ",0);
                            CFGCUR++;
                            if(CFGCUR==16)CFGCUR=0;
                        }
                        u8 VALUE=0;
                        if(Pad.Pressed.Left)VALUE=255;
                        if(Pad.Pressed.Right)VALUE=1;
                        switch(CFGCUR)
                        {
                            case 0:
                                if(VALUE==1)T_WRAP=1;
                                if(VALUE==255)T_WRAP=0;
                                break;
                            case 1:
                                if(VALUE==1)VUMETERS=1;
                                if(VALUE==255)VUMETERS=0;
                                break;
                            case 2:
                                if((VALUE==1)&&(PALETTE<5))
                                {
                                    PALETTE++;
                                    updatepal();
                                }
                                else
                                if((VALUE==255)&&(PALETTE>0))
                                {
                                    PALETTE--;
                                    updatepal();
                                }
                                break;
                            case 3:
                                switch(VALUE)
                                {
                                    case 1:
                                        if(SYSTEM_SKIN<5)
                                        {
                                            SYSTEM_SKIN++;
                                            updateskin();
                                        }
                                        break;
                                    case 255:
                                        if(SYSTEM_SKIN>0)
                                        {
                                            SYSTEM_SKIN--;
                                            updateskin();
                                        }
                                break;
                        }
                        break;
                    case 4:
                        switch(VALUE)
                        {
                            case 1:
                                if(SYSTEM_FONT<5)
                                {
                                    SYSTEM_FONT++;
                                    updatefont();
                                }
                                break;
                            case 255:
                                if(SYSTEM_FONT>0)
                                {
                                    SYSTEM_FONT--;
                                    updatefont();
                                }
                                break;
                        }
                        break;
                    case 5:
                        break;
                }
                //end of controller info*************************************************************

}

void GetInput_File(void)
{
    #ifdef MIKE_ADDITIONS
        if(Pad.Pressed.A)
        {
            save_song();
        }
        if(Pad.Pressed.B)
        {
            load_song();
        }
        if(Pad.Pressed.Select)
        {
        ham_ResetRAM();
        }
    #endif
}
