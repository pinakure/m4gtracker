void InitInput(void)
{
    ham_InitPad();
    KEYPAD_OFF.A=FALSE;
    KEYPAD_OFF.B=FALSE;
    KEYPAD_OFF.L=FALSE;
    KEYPAD_OFF.R=FALSE;
    KEYPAD_OFF.u=FALSE;
    KEYPAD_OFF.d=FALSE;
    KEYPAD_OFF.l=FALSE;
    KEYPAD_OFF.r=FALSE;
    KEYPAD_OFF.s=FALSE;
    KEYPAD_OFF.S=FALSE;
    KEYPAD=KEYPAD_OFF;
}


void InitSound(void)
{
    //init channel 1  pulse
    REG_IF |= REG_IF;
	REG_SOUNDCNT_X = 0x80;	     //turn on sound circuit		
    REG_SOUNDCNT_L = 0xFF77;	
	REG_SOUNDCNT_H = 2;		    // Overall output ratio - Full	
}

void InitGFX(void)
{
    ham_StartIntHandler(INT_TYPE_VBL,frame);
    ham_SetBgMode(0);
    ham_SetBgPalCol(3,COLOR_YELLOW);
    ham_SetBgPalCol(2,COLOR_MAROON);
    ham_SetBgPalCol(1,COLOR_RED);
    ham_LoadBGPal256(&pal0);//,0);
    font = ham_InitTileEmptySet(112,1,1);
    ham_ReloadTileGfx(font,(void*)&font_tiles_00,0,255);
    ham_bg[0].ti = font;
    ham_bg[0].mi = ham_InitMapEmptySet(0,0);
    ham_bg[2].ti = ham_InitTileSet((void*)&font_tiles_00, SIZEOF_16BIT(font_tiles_00),1,0);
    ham_bg[2].mi = ham_InitMapEmptySet(0,0);
    ham_bg[3].ti = ham_InitTileSet((void*)&font_tiles_00, SIZEOF_16BIT(font_tiles_00),1,0);
    ham_bg[3].mi = ham_InitMapEmptySet(0,0);
    ham_InitBg(0,1,0,0);
    //ham_InitBg(1,1,10);
    ham_InitBg(2,1,2,0);
    ham_InitBg(3,1,3,0);
    ClearText(0);
    ClearText(1);
    ClearText(2);
    ClearText(3);
}
//**************************************************************************************//
void InitSong()
{
    ham_InitRAM(RAM_TYPE_SRAM_256K);
    SONG = malloc(1024 * sizeof (struct pattern_order));
    PATTERN= malloc(256 * sizeof (struct tracker_pattern));
    #ifdef MIKE_ADDITIONS
        pat_hdr.max_pat = 1;
    #endif
    u8 j,k,l;
    u16 n;
    for(j=0;j<255;j++)
    {
        for(k=0;k<NUM_CHANNELS;k++)
        {
            for(l=0;l<16;l++)
            {
                PATTERN[j].CHANNEL[k].note[l]=101;
            }
        }
    }
    for(n=0;n<1023;n++)
    {
        SONG[n].index=0;
    }

}
//**************************************************************************************//
void init(void)
{
    ham_Init();
    InitSound();
    InitSong();
    InitInput();
    InitGFX();
}
//**************************************************************************************//




