void PlaySong(void)
{
    /********************************************************************************/
    // PLAYEX : PLAY CODE EXTENDED                                                  **
    /********************************************************************************/
    if(PLAYING)
    {
        if(TEMPO_TIMER>(TEMPO_TIME-1)+TEMPO_FIX)
        {
            //************************************************************************
            //****     R E A D      N O T E     **************************************
            //************************************************************************
            {
                PULSE1(PWM_FREQ_TABLE[PATTERN[SONG[SNG_POS].index].CHANNEL[0].note[PAT_POS]]);
                PULSE2(PWM_FREQ_TABLE[PATTERN[SONG[SNG_POS].index].CHANNEL[1].note[PAT_POS]]);
                /*NOISE(PWM_FREQ_TABLE[PATTERN[SNG_POS].CHANNEL[2].note[PAT_POS]]);
                WAVE(PWM_FREQ_TABLE[PATTERN[SNG_POS].CHANNEL[3].note[PAT_POS]]);
                DSOUND1(PWM_FREQ_TABLE[PATTERN[SNG_POS].CHANNEL[4].note[PAT_POS]]);
                DSOUND2(PWM_FREQ_TABLE[PATTERN[SNG_POS].CHANNEL[5].note[PAT_POS]]);
                FM1(PWM_FREQ_TABLE[PATTERN[SNG_POS].CHANNEL[6].note[PAT_POS]]);
                FM2(PWM_FREQ_TABLE[PATTERN[SNG_POS].CHANNEL[7].note[PAT_POS]]);*/
            }
            //************************************************************************
            //****     R E A D      V O L  COL  **************************************
            //************************************************************************
            {
            }
            //************************************************************************
            //****     R E A D      F X C  COL  **************************************
            //************************************************************************
            {
            }
            //************************************************************************
            //****     R E A D      F X P  COL  **************************************
            //************************************************************************
            {
            }
            //****�?�?�?� MIDI ?�?�?�?************************************************
            //************************************************************************
            {
            }
            //************************************************************************
            //****     C A R R I E R  ************************************************
            //************************************************************************
            {
                PAT_POS++;
                TEMPO_TIMER=0;
                if(!PLAYSONG)
                {
                    if(PAT_POS>15)PAT_POS=0;
                    REDRAWTRACKERCURSOR=1;
                    REDRAWTRACKERBG=1;
                }
                else
                {
                    REDRAWTRACKERCURSOR=1;
                    REDRAWTRACKERBG=1;
                    if(PAT_POS>15)
                    {
                        SNG_POS++;
                        PAT_POS=0;
                        if(SNG_POS>SNG_LEN)SNG_POS=SNG_JMP;
                        REDRAWTRACKER=1;
                    }
                }
            }
        }
        else
        {
            TEMPO_TIMER++;
        }
    }
}
//**************************************************************************************//
void PULSE2(u16 freq)
{
    if(freq>0)
    {
        REG_SOUND2CNT_L=0xf780; //duty=50%,envelope decrement
        REG_SOUND2CNT_H=0x8f00; //frequency=0x0400, loop mode	

        REG_SOUND2CNT_L=(envinit<<12)+(envdir<<11)+(envsteptime<<8)+(waveduty<<6)+soundlength;
        REG_SOUND2CNT_H=freq;
    }   	
}
//***************************************************************************************
void PULSE1(u16 freq)
{
    if(freq>0)
    {
        //REG_SOUND1CNT_L=0x0056; //sweep shifts=6, increment, sweep time=39.1ms
        REG_SOUND1CNT_L=0x0000; //sweep shifts=6, increment, sweep time=39.1ms
        REG_SOUND1CNT_H=0xf780; //duty=50%,envelope decrement
        REG_SOUND1CNT_X=0x8f00; //frequency=0x0400, loop mode
	   //play the sound		
	   {
	       sweeptime=0;
           sweepshifts=0;

           //REG_SOUND1CNT_L=(sweeptime<<4)+(sweepdir<<3)+sweepshifts;
	       //REG_SOUND1CNT_X=SOUND1INIT+(loopmode<<14)+sfreq;
   	       REG_SOUND1CNT_H=(envinit<<12)+(envdir<<11)+(envsteptime<<8)+(waveduty<<6)+soundlength;
	
           //REG_SOUND1CNT_X=(freq)+(loopmode<<14);

           REG_SOUND1CNT_X=freq;
	   }
    }
}
//**************************************************************************************//
void NOISE(u16 freq)
{
    if(freq>0)
    {
        u8 stepping =3;
        u8 freq_ratio=2;
        REG_SOUND4CNT_L=(envinit<<12)+(envdir<<11)+(envsteptime<<8)+soundlength;
	   REG_SOUND4CNT_H=SOUND4INIT+(loopmode<<14)+(freq<<4)+(stepping<<3)+freq_ratio;
    }
}
//**************************************************************************************//

