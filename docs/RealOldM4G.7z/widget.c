void frame(void)
{
    REDRAW=1;
}

void updateskin(void)
{

}

void updatefont(void)
{
    switch(SYSTEM_FONT)
    {
        case 0:ham_ReloadTileGfx(font,(void*)&font_tiles_00,0,255);break;
        case 1:ham_ReloadTileGfx(font,(void*)&font_tiles_01,0,255);break;
        case 2:ham_ReloadTileGfx(font,(void*)&font_tiles_02,0,255);break;
        case 3:ham_ReloadTileGfx(font,(void*)&font_tiles_03,0,255);break;
        case 4:ham_ReloadTileGfx(font,(void*)&font_tiles_04,0,255);break;
        case 5:ham_ReloadTileGfx(font,(void*)&font_tiles_05,0,255);break;
    }
    ClearText(0);
}                                                                                       //



// BOX: Holds a number inside, variable size of the box and currency                    **
void Box(u8 x,u8 y, u8 len, u16 val,bool onlynumber,bool highlight)
{
    itoa(val,(char*)value);
    PutText(x,y,(char*)value,highlight);
        if(val<10)
        {
            ham_SetMapTile(0,x+1,y,255);
            if(len>2)ham_SetMapTile(0,x+2,y,255);
            if(len>3)ham_SetMapTile(0,x+3,y,255);
        }
        else
        {
            if(val<100)
            {
                if(len>2)ham_SetMapTile(0,x+2,y,255);
                if(len>3)ham_SetMapTile(0,x+3,y,255);
            }
        }
    if(!onlynumber)
    {
        if(len>2)
        {
            u8 c;
            ham_SetMapTile(2,x,y,244);
            for(c=1;c<len-1;c++)
            {
                ham_SetMapTile(2,x+c,y,245);
            }
            ham_SetMapTile(2,x+len-1,y,246);
        }
        else
        {
            ham_SetMapTile(2,x,y,244);
            ham_SetMapTile(2,x+1,y,246);
        }
    }
}

