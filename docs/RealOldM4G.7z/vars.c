#include "data/palette/pal0.c"
#include "data/palette/pal1.c"
#include "data/palette/pal2.c"
#include "data/palette/pal3.c"
#include "data/palette/pal4.c"
#include "data/palette/pal5.c"
#include "data/font/font00.c"
#include "data/font/font01.c"
#include "data/font/font02.c"
#include "data/font/font03.c"
#include "data/font/font04.c"
#include "data/font/font05.c"
/*#include "data/skin/skin00.c"
#include "data/skin/skin01.c"
#include "data/skin/skin02.c"
#include "data/skin/skin03.c"
#include "data/skin/skin04.c"
#include "data/skin/skin05.c"*/

char *enabool(bool val);
char *getpalettename(u8 index);
char *getfontname(void);
char *getskinname(void);
tile_info_ptr font;
/*char *NOTE_NAMES[102]={"C-0","C#0","D-0","D#0","E-0","F-0","F#0","G-0","G#0","A-0","A#0","B-0",
						"C-1","C#1","D-1","D#1","E-1","F-1","F#1","G-1","G#1","A-1","A#1","B-1",
						"C-2","C#2","D-2","D#2","E-2","F-2","F#2","G-2","G#2","A-2","A#2","B-2",
						"C-3","C#3","D-3","D#3","E-3","F-3","F#3","G-3","G#3","A-3","A#3","B-3",
						"C-4","C#4","D-4","D#4","E-4","F-4","F#4","G-4","G#4","A-4","A#4","B-4",
						"C-5","C#5","D-5","D#5","E-5","F-5","F#5","G-5","G#5","A-5","A#5","B-5",
						"C-6","C#6","D-6","D#6","E-6","F-6","F#6","G-6","G#6","A-6","A#6","B-6",
						"C-7","C#7","D-7","D#7","E-7","F-7","F#7","G-7","G#7","A-7","A#7","B-7",
						"C-8","C#8","D-8","D#8","=-=","---"};
u16 FREQ_TABLE[102]={   16,	17,	 18,  19,  20,	21,	 23,  24,  25,  27,  29,  30,
                        32,	34,	 36,  38,  41,	43,	 46,  49,  51,	55,  58,  61,
                        65,	69,	 73,  77,  82,	87,	 92,  98, 103, 110, 116, 123,
                        130, 138, 146, 155, 164, 174, 185, 196, 207, 220, 233, 246,
                        261, 277, 293, 311, 329, 349, 369, 392, 415, 440, 466, 493,
                        523, 554, 587, 622, 659, 698, 739, 783, 830, 880, 932, 987,
                        1046,1108,1174,1244,1318,1396,1479,1567,1661,1760,1864,1975,
                        2093,2217,2349,2489,2637,2793,2959,3135,3322,3520,3729,3951,
                        4186,4434,4698,4978,0,0};*/
                        
char *NOTE_NAMES[102]={"C-0","C#0","D-0","D#0","E-0","F-0","F#0","G-0","G#0","A-0","A#0","B-0",
						"C-1","C#1","D-1","D#1","E-1","F-1","F#1","G-1","G#1","A-1","A#1","B-1",
						"C-2","C#2","D-2","D#2","E-2","F-2","F#2","G-2","G#2","A-2","A#2","B-2",
						"C-3","C#3","D-3","D#3","E-3","F-3","F#3","G-3","G#3","A-3","A#3","B-3",
						"C-4","C#4","D-4","D#4","E-4","F-4","F#4","G-4","G#4","A-4","A#4","B-4",
						"C-5","C#5","D-5","D#5","E-5","F-5","F#5","G-5","G#5","A-5","A#5","B-5",
						"C-6","C#6","D-6","D#6","E-6","F-6","F#6","G-6","G#6","A-6","A#6","B-6",
						"C-7","C#7","D-7","D#7","E-7","F-7","F#7","G-7","G#7","A-7","A#7","B-7",
						"C-8","C#8","D-8","D#8","=-=","---"};
u16 PWM_FREQ_TABLE[102]={  0,     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,   20,
                          44,   156,  262,  363,  457,  547,  631,  710,  786,  854,  923,  986,
                         1046, 1102, 1155, 1205, 1253, 1297, 1339, 1379, 1417, 1452, 1486, 1517,
                         1546, 1575, 1602, 1627, 1650, 1673, 1694, 1714, 1732, 1750, 1767, 1783,
                         1798, 1812, 1825, 1837, 1849, 1860, 1871, 1881, 1890, 1899, 1907, 1915,
                         1923, 1930, 1936, 1946, 1949, 1954, 1959, 1964, 1969, 1974, 1978, 1982,
                         1985, 1988, 1992, 1995, 1998, 2001, 2004, 2006, 2009, 2011, 2013, 2015,
                         2017, 2019, 2021, 2023, 2025, 2027, 2029, 2031, 2033, 2035, 2037, 2039,
                            0,    0,    0,    0,    0,    0};

char number(u8 num);
u8 PALETTE=0;
bool REDRAW=0;
char *value[2];
//*SONG ARS*******************************************************************************
u8 LEVEL=0;
bool PLAYSONG=0;
u8 TEMPO=125;
u8 TEMPO_FIX=0;   //<<--- this timer addon should fix timing issues, be sure to tweak eveytime you modify the speed of a menu!!!
u8 TEMPO_TIME=2;
u8 TEMPO_TIMER=0;
//*MENU VARS******************************************************************************
u8 CFGCUR=0;
u8 CURSNG=0;
u8 MENU=0;
u8 MENUSWITCH=0;
bool RESET=0;
u8 SYSTEM_FONT=0;
u8 SYSTEM_SKIN=0;
u16 SNG_LISTOFFSET=0;
//CONFIGURABLE VARIABLES******************************************************************
bool P_WRAP=1;
bool T_WRAP=1;
bool VUMETERS=1;
//*TRACKER VARIABLES**********************************************************************
u8 CHANNEL=0;
u8 CURSOR=0;
u8 INSVALUE=0;
u8 KEYVALUE=0;
u8 PAT_POS=0;
u8 PARVALUE=0;
bool PLAYING=0;
bool REDRAWTRACKER=1;
bool REDRAWTRACKERBG=1;
bool REDRAWTRACKERCURSOR=1;
bool REDRAWGAUGES=1;
bool SPECIALCOLUMN=0;
u8 SFXVALUE=0;
u8 SNG_POS=0;
u16 SNG_JMP=0;
u16 SNG_LISTVALUE=0;
u16 SNG_LEN=15;
u8 VOLVALUE=0;
//*KEYPAD VARIABLES***********************************************************************
bool GETINPUT=0;
bool KEY_DISPONIBLE=0;
u8 KEY_TIMER=0;
u8 KEY_RATE=250;
//used by channel 1 sound system********************************************************//
u16 note;                                                                               //
u16 delta,u,sweepshifts=2,sweepdir=1,sweeptime=7,cur=6;                                 //
u16 envinit=0xf, envdir=0, envsteptime=7,waveduty=2,soundlength=1;                      //
u16 loopmode=0,sfreq=0x400,resamp=1;                                                    //
