#define KEYPAD_OFF   INPUT[0]
#define KEYPAD       INPUT[1]
#define KEYPAD_PRESS INPUT[2]
#define KEYPAD_RESET   KEYPAD=KEYPAD_OFF
#define KEYPAD_PRESS_RESET   KEYPAD_PRESS=KEYPAD_OFF
#define KEYPAD_ENABLE  {KEY_DISPONIBLE=TRUE;KEY_TIMER=0;}
#define KEYPAD_COOL  {KEY_DISPONIBLE=FALSE;KEY_TIMER=0;}
#define DEBUG

#ifdef MULTI
    MULTIBOOT
#endif
#define MIKE_ADDITIONS

#define SWAP_CHAR( x, y ) {char c; c = x; x = y; y = c;}
#define NUM_CHANNELS 6

