//**************************************************************************************//
//   M4GTRACKER PROJECT - NsN Technicians, (R)                                          //
//   By Mitikoro & Smiker                                                               //
//**************************************************************************************//
//   TEXT.C                                                                             //
//   This holds the code responsible of handling strings and painting them on the screen//
//**************************************************************************************//
// Function WINDOW: Draw a window of spicified geometry and type on layer BG3           **
void Window(u8 Sx,u8 Sy,u8 Tx,u8 Ty,bool Marco)
{
    bool Draw=TRUE;
    u32 Index=0;
    int x=0;
    int y=0;
    if(Marco==TRUE)Index=208;
    if(Marco==FALSE)Index=216;
    for(y=Sy;y<Ty+1;y++)
    {
        for(x=Sx;x<Tx+1;x++)
        {
            Draw=TRUE;
            if(x==Sx)
            {
                if(y==Sy)ham_SetMapTile(3,x,y,Index);
                if(y==Ty)ham_SetMapTile(3,x,y,Index+5);
                if((y>Sy)&&(y<Ty))ham_SetMapTile(3,x,y,Index+3);
                Draw=FALSE;
            }
            if(x==Tx)
            {
                if(y==Sy)ham_SetMapTile(3,x,y,Index+2);
                if(y==Ty)ham_SetMapTile(3,x,y,Index+7);
                if((y>Sy)&&(y<Ty))ham_SetMapTile(3,x,y,Index+4);
                Draw=FALSE;
            }
            if(y==Sy)
            {
                if((x>Sx)&&(x<Tx))ham_SetMapTile(3,x,y,Index+1);
                Draw=FALSE;
            }
            if(y==Ty)
            {
                if((x>Sx)&&(x<Tx))ham_SetMapTile(3,x,y,Index+6);
                Draw=FALSE;
            }
            if(Draw)ham_SetMapTile(3,x,y,255);
        }
    }
}                                                                                       //
//****************************************************************************************
// Function REVERSE: Reverses the characters on a string                                **
void reverse(char t[])
{
  u8 i,j;
  for(i = 0, j = strlen(t)-1; i < j; i++, j--)
    SWAP_CHAR(t[i], t[j]);
}                                                                                       //
//****************************************************************************************
// Function ITOA: Returns a string containing the value of the specified integer        **
//! I think this funcion is fuckin slow. U_u'' ...*****/
void itoa(int n, char s[])
{
    u8 i=0;
    do
    {
        s[i++] = n % 10 + '0';   /* get next digit */
    }while ((n /= 10) > 0);      /* delete it */
    s[i] = '\0';
    reverse(s);
}                                                                                       //
//****************************************************************************************
// Function CLEARTEXT: Clears the specified BG Layer                                    **
void ClearText(u8 layer)
{
    int x=0;
    int y=0;
    for (y=0;y<20;y++)
    {
        for(x=0;x<30;x++)
        {
            if(layer==0)ham_SetMapTile(0,x,y,111);
            if(layer==1)ham_SetMapTile(1,x,y,255);
            if(layer==2)ham_SetMapTile(2,x,y,255);
            if(layer==3)ham_SetMapTile(3,x,y,255);
        }
    }
}                                                                                       //
//****************************************************************************************
// Function ENABOOL: Returns a string containing enabled or disbled depending on the par**
char *enabool(bool val)
{
    if(val==1)return("ENABLED ");
    if(val==0)return("DISABLED");
    return(0);
}                                                                                       //
//****************************************************************************************
// Function TAB: Draws a TAB of the specified type on x,y , on layer BG3                **
void tab(u8 x,u8 y,u8 highlight)
{
    u8 y2=y+1,t;
    if(highlight>0)highlight=8;
    for(t=0;t<4;t++)
    {
        ham_SetMapTile(3,x+t,y,224+t+highlight);
        ham_SetMapTile(3,x+t,y2,228+t+highlight);
    }
}                                                                                       //
//****************************************************************************************
// Function MICROGAUGE: Draws a piece of Gauge(VU-METER)with its backdrop on BG3&BG3    **
void microgauge(u8 x,u8 y,u8 type,u8 level)
{
    ham_SetMapTile(3,x,y,194-type);
    switch(level)
    {
        case 0:
            ham_SetMapTile(2,x,y,255);
            break;
        case 1:
            ham_SetMapTile(2,x,y,197-type);
            break;
        case 2:
            ham_SetMapTile(2,x,y,200-type);
            break;
        case 3:
            ham_SetMapTile(2,x,y,203-type);
            break;
        case 4:
            ham_SetMapTile(2,x,y,206-type);
            break;
    }
}                                                                                       //
//****************************************************************************************
// Function GAUGE: Composes a gauge, filling it with the desired base 50 level.         **
void gauge(u8 x, u8 y, u8 level)
{
    level/=2;
    u8 r,c=0;
    for(r=0;r<10;r++)
    {
        if(r>6)c=1;
        if(r>8)c=2;
        if(level<r)ham_SetMapTile(2,x+r,y,194-c);
        microgauge(x+r,y,c,level-(r*5));
    }
}                                                                                       //
//****************************************************************************************
// Function HEXPRINT: Returns a string containing the system's font name                **
void hexprint(u8 precision, u8 x, u8 y, u8 n, bool h)
{
    switch(n)
    {
        case 0: case 1: case 2: case 3:case 4:case 5:case 6:case 7:case 8:case 9:
            itoa(n,(char*)value);
            PutText(x,y,(char*)value,h);
            break;
        case 10:
            PutText(x,y,"A",h);
            break;
        case 11:
            PutText(x,y,"B",h);
            break;
        case 12:
            PutText(x,y,"C",h);
            break;
        case 13:
            PutText(x,y,"D",h);
            break;
        case 14:
            PutText(x,y,"E",h);
            break;
        case 15:
            PutText(x,y,"F",h);
            break;
    }
}                                                                                       //
//****************************************************************************************
// Function GETPALETTENAME: Returns a string containing the system's palette name       **
char *getpalettename(u8 index)
{
    switch(index)
    {
        case 0:return("ROCK     ");break;
        case 1:return("OCEAN    ");break;
        case 2:return("LAWLYET  ");break;
        case 3:return("COBRA    ");break;
        case 4:return("KITTEN   ");break;
        case 5:return("NIGHTMARE");break;
    }
    return(0);
}                                                                                       //
//****************************************************************************************
// Function UPDATEPAL: Updates system's color palette                                   **
void updatepal(void)
{
    switch(PALETTE)
    {
        case 0:ham_LoadBGPal256(&pal0);break;//rock
        case 1:ham_LoadBGPal256(&pal1);break;//ocean
        case 2:ham_LoadBGPal256(&pal2);break;//lawlyet
        case 3:ham_LoadBGPal256(&pal3);break;//cobra
        case 4:ham_LoadBGPal256(&pal4);break;//kitten<<----
        case 5:ham_LoadBGPal256(&pal5);break;//nightmare
    }
}                                                                                       //
//****************************************************************************************
// Function GETFONTNAME: Returns a string containing the system's font name             **
char *getfontname(void)
{
    switch(SYSTEM_FONT)
    {
        case 0:return("FUTURE   ");break;
        case 1:return("NINJUTSU ");break;
        case 2:return("SMK SOFT ");break;
        case 3:return("SMK ROUGH");break;
        case 4:return("ARCADE   ");break;
        case 5:return("DIGITAL  ");break;
    }
    return(0);
}                                                                                       //
//****************************************************************************************
// Function PUTTEXT: Print the specified string on the layer number bg0                 **
void PutText(int X,int Y,char Text[],bool Colored)
{
    u8 Color=0;
    if(Colored==1)Color=48;
    bool Symbol=FALSE;
    char Parsed;
    int Parse=0;
    u8 v=0;
    while(Text[v]!='\0')
    {
        v++;
    }
    for(Parse=0;Parse<v;Parse++)
    {
        switch(Text[Parse])
        {
            case '0':case '1':case '2':case '3':case '4':case '5':
            case '6':case '7':case '8':case '9':
                Parsed=Text[Parse]-47;
                Parsed+=25;
                Symbol=FALSE;
                break;
            default:
                if((Text[Parse] >= 'A') && (Text[Parse] <= 'Z'))
                {
                    Parsed=Text[Parse]-65;
                    Symbol=FALSE;
                }
                else
                {
                    if((Text[Parse] >= 'a') && (Text[Parse] <= 'z'))
                    {
                        Parsed=Text[Parse]-97;
                        Symbol=FALSE;
                    }
                    else
                    {
                        Parsed=Text[Parse];
                        Symbol=TRUE;
                    };
                };
                break;
        };
        switch(Symbol)
        {
            case TRUE:
                switch(Parsed)
                {
                    case '!':Parsed=36;break;
                    case '?':Parsed=37;break;
                    case '[':Parsed=38;break;
                    case ']':Parsed=39;break;
                    case '(':Parsed=40;break;
                    case ')':Parsed=41;break;
                    case '.':Parsed=42;break;
                    case ',':Parsed=43;break;
                    case ':':Parsed=44;break;
                    case '-':Parsed=45;break;
                    case '|':Parsed=46;break;
                    case '#':Parsed=47;break;
                    case '>':Parsed=98;break;
                    case '*':/*Parsed=257;*/break;
                    default:Parsed=111;break;
                }
                if (Text[Parse]!=' ')
                {
                    ham_SetMapTile(0,X+Parse,Y,Parsed+Color);
                }
                else
                {
                    if (Text[Parse]==' ')ham_SetMapTile(0,X+Parse,Y,111);
                }
                break;
            case FALSE:
                ham_SetMapTile(0,X+Parse,Y,Parsed+Color);
                break;
        }
    }
}                                                                                       //
//****************************************************************************************
// Function ITOAX: Convert a u8 to hex and draw it at coordinates specified             **
void itoax(u8 x, u8 y, u8 number,bool c)
{
    bool bit1=0,bit2=0,bit3=0,bit4=0,bit5=0,bit6=0,bit7=0,bit8=0;
    u8 c1=0;
    u8 c2=0;
    char hex[2];
    bit1=number & (1<<0);
    bit2=number & (1<<1);
    bit3=number & (1<<2);
    bit4=number & (1<<3);
    bit5=number & (1<<4);
    bit6=number & (1<<5);
    bit7=number & (1<<6);
    bit8=number & (1<<7);
    if(bit8)c1+=8;
    if(bit7)c1+=4;
    if(bit6)c1+=2;
    if(bit5)c1+=1;
    if(bit4)c2+=8;
    if(bit3)c2+=4;
    if(bit2)c2+=2;
    if(bit1)c2+=1;
    switch(c1)
    {
        case 0:hex[0]='0';break;
        case 1:hex[0]='1';break;
        case 2:hex[0]='2';break;
        case 3:hex[0]='3';break;
        case 4:hex[0]='4';break;
        case 5:hex[0]='5';break;
        case 6:hex[0]='6';break;
        case 7:hex[0]='7';break;
        case 8:hex[0]='8';break;
        case 9:hex[0]='9';break;
        case 10:hex[0]='A';break;
        case 11:hex[0]='B';break;
        case 12:hex[0]='C';break;
        case 13:hex[0]='D';break;
        case 14:hex[0]='E';break;
        case 15:hex[0]='F';break;
    };
    switch(c2)
    {
        case 0:hex[1]='0';break;
        case 1:hex[1]='1';break;
        case 2:hex[1]='2';break;
        case 3:hex[1]='3';break;
        case 4:hex[1]='4';break;
        case 5:hex[1]='5';break;
        case 6:hex[1]='6';break;
        case 7:hex[1]='7';break;
        case 8:hex[1]='8';break;
        case 9:hex[1]='9';break;
        case 10:hex[1]='A';break;
        case 11:hex[1]='B';break;
        case 12:hex[1]='C';break;
        case 13:hex[1]='D';break;
        case 14:hex[1]='E';break;
        case 15:hex[1]='F';break;
   }
   PutText(x,y,(char*)hex,c);
}                                                                                       //
//****************************************************************************************
char *getskinname()
{
    switch(SYSTEM_SKIN)
    {
        case 0:return("STONE   ");break;
        case 1:return("STONE   ");break;
        case 2:return("STONE   ");break;
        case 3:return("STONE   ");break;
        case 4:return("STONE   ");break;
        case 5:return("STONE   ");break;
    }
    return(0);
}


