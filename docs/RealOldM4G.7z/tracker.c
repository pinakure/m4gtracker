//**************************************************************************************//
//   M4GTRACKER PROJECT - NsN Technicians, (R)                                          //
//   By Mitikoro & Smiker                                                               //
//**************************************************************************************//
//   TRACKER.C                                                                          //
//   This holds the graphics code inside the tracker screen tab                         //
//**************************************************************************************//
void Draw_Tracker_Cursor(void)
{//tracker cursor section
    u8 co,c;
    u8 position=PAT_POS;
    if(REDRAWTRACKERBG)
    {
        for(co=0;co<position;co++)
        {
            for(c=0;c<30;c++)ham_SetMapTile(2,c,4+co,253);
        }
        for(co=position;co<16;co++)
        {
            for(c=0;c<30;c++)ham_SetMapTile(3,c,4+co,253);
            for(c=0;c<30;c++)ham_SetMapTile(2,c,4+co,255);
        }
        REDRAWTRACKERBG=0;
    }
    if(REDRAWTRACKERCURSOR)
    {
        for(c=0;c<CURSOR-1;c++)
        {
            ham_SetMapTile(2,c+1,4+position,245);
        }
        for(c=CURSOR+4;c<29;c++)
        {
            ham_SetMapTile(2,c+1,4+position,245);
        }
        REDRAWTRACKERCURSOR=0;
        switch(CURSOR)
        {
            case 0:case 10:case 20:
                if(CURSOR==0)
                {
                    ham_SetMapTile(2,29,4+position,245);
                }
                {
                    ham_SetMapTile(2,CURSOR-1,4+position,245);
                    ham_SetMapTile(2,CURSOR,4+position,245);
                    ham_SetMapTile(2,1+CURSOR,4+position,206);
                    ham_SetMapTile(2,2+CURSOR,4+position,206);
                    ham_SetMapTile(2,3+CURSOR,4+position,206);
                    ham_SetMapTile(2,4+CURSOR,4+position,245);
                }
                break;
            case 1:case 2:case 3:case 4:case 5:case 6:case 11:case 12:case 13:case 14:case 15:case 16:case 21:case 22:case 23:case 24:case 25:case 26:
                if(CURSOR==26)
                {
                    ham_SetMapTile(2,1,4+position,245);
                    ham_SetMapTile(2,2,4+position,245);
                    ham_SetMapTile(2,3,4+position,245);
                }
                {
                    ham_SetMapTile(2,CURSOR,4+position,245);
                    ham_SetMapTile(2,1+CURSOR,4+position,245);
                    ham_SetMapTile(2,2+CURSOR,4+position,245);
                    ham_SetMapTile(2,3+CURSOR,4+position,206);
                    ham_SetMapTile(2,4+CURSOR,4+position,245);
                    ham_SetMapTile(2,5+CURSOR,4+position,245);
                    ham_SetMapTile(2,6+CURSOR,4+position,245);
                    ham_SetMapTile(2,7+CURSOR,4+position,245);
                }
                break;
            case 7://jump
                CHANNEL=1;
                CURSOR=10;
                break;
            case 9://jump
                CHANNEL=0;
                CURSOR=6;
                break;
            case 17://jump
                CHANNEL=2;
                CURSOR=20;
                break;
            case 19://jump
                CHANNEL=1;
                CURSOR=16;
                break;
            case 27://jump
                CHANNEL=0;
                CURSOR=0;
                break;
            case 255:
                CHANNEL=2;
                CURSOR=26;
                break;
        }
    }
}
//**************************************************************************************//
void Draw_Tracker(void)
{
    if(MENUSWITCH)
    {//Tasks To Do Once Switching Only   //
        ClearText(0);
        ClearText(2);
        ClearText(3);
        TEMPO_FIX=0;
        //tab section*********************************************************************
        PutText( 1,0x01,"PATT",0);
        PutText( 5,0x01,"samp",1);
        PutText( 9,0x01,"inst",1);
        PutText(13,0x01,"song",1);
        PutText(17,0x01,"live",1);
        PutText(21,0x01,"file",1);
        PutText(25,0x01,"cfg",1);
        tab(1,0,0);tab(5,0,1);tab(9,0,1);tab(13,0,1);tab(17,0,1);tab(21,0,1);tab(25,0,1);
        ham_SetMapTile(3,0,0,255);
        ham_SetMapTile(3,0,1,236);
        ham_SetMapTile(3,29,0,255);
        ham_SetMapTile(3,29,1,236);
        #ifndef DEBUG
            PutText(0,0x02,"   PWM1",1);
            PutText(10,0x02,"   PWM2",1);
            PutText(20,0x02,"  NOISE",1);
        #endif
        u8 i=0;
        for(i=0;i<16;i++)
        {
            hexprint(0,0,4+i,i,1);
        }
        MENUSWITCH=0;
        REDRAWTRACKER=1;
        REDRAWTRACKERCURSOR=1;
        REDRAWTRACKERBG=1;
    }		
    if(REDRAWGAUGES)
    {
        gauge(0,3,LEVEL);
        gauge(10,3,LEVEL);
        gauge(20,3,LEVEL);
        REDRAWGAUGES=0;
    }
    //get control information*************************************************************
   //**************TRACKER GFX REDRAW CODE***********************************************
    Draw_Tracker_Cursor();
    if(REDRAWTRACKER)
    {
        u8 i=0,co=0,c;
        for(i=0;i<16;i++)
        {
            co=0;
            for(c=0;c<30;c+=10)
            {
                PutText(1+c,0x04+i,NOTE_NAMES[PATTERN[SONG[SNG_POS].index].CHANNEL[co].note[i]],0);
                itoax(4+c,0x04+i,PATTERN[SONG[SNG_POS].index].CHANNEL[co].ins[i],1);
                if(SPECIALCOLUMN)itoax(6+c,0x04+i,PATTERN[SONG[SNG_POS].index].CHANNEL[co].fxc[i],0);
                else itoax(6+c,0x04+i,PATTERN[SONG[SNG_POS].index].CHANNEL[co].vol[i],0);
                itoax(8+c,0x04+i,PATTERN[SONG[SNG_POS].index].CHANNEL[co].fxp[i],1);
                if(c<20)PutText(10+c,0x04+i,"*",0);
                co++;
            }
        }
        REDRAWTRACKER=0;
    }
    #ifdef DEBUG
    {
        itoa(REG_SOUND1CNT_X,(char*)value);
        PutText(0,0x02,(char*)value,1);
        LEVEL++;
        if(LEVEL>100)LEVEL=0;
        REDRAWGAUGES=1;
    }
    #endif


}

