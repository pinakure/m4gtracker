void Draw_Live(void)
{
    TEMPO_FIX=60;
    //tab section*************************************************************
    tab(1,0,1);tab(5,0,1);tab(9,0,1);tab(13,0,1);tab(17,0,0);tab(21,0,1);tab(25,0,1);
    PutText( 1,0x01,"patt",1);
    PutText( 5,0x01,"samp",1);
    PutText( 9,0x01,"inst",1);
    PutText(13,0x01,"song",1);
    PutText(17,0x01,"LIVE",0);
    PutText(21,0x01,"file",1);
    PutText(25,0x01,"cfg",1);
    //draw live menu**********************************************************
    if(MENUSWITCH==1)ClearText(0);
}
                        

