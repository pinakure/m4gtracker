//////////////////////////////////////////////////////////////////////////////////////////
//                         \\_           /\_     \''\''''l                              //
//                         \ \_        / \ \_    \  \   l                               //
//                         \  \_     /   \  \    \  \  l    _____                       //
//                         \   \_   \    \  \    \  \ l   /     \         *             //
//                         \    \_  \    \  \    \  \ \  \_     \_           *          //
//                         \     \__\    \  \___/   \ \   \____  /        *             //
//                         \             \_         \ \       \ \         *             //
// **                    * \    _     _  \\_        \ \_______/ \         *             //
//  **                 ** *\  / \_   \\_ \ \______  \         ,/         **             //
// *  ***           ***  **\ \   \__/  \ \       \  \       ,/          ****          **//
// ------------------------\/----------\/--------\_/\______/----------------------------//
//********************* *   *     *  T R A C K E R  *     *   *  * * *******************//
//  N S N   Technicians, Inc.                                                           //
//  MAIN CODERS:                                                                        //
//  Smiker              Mitikoro                                                        //
//  Project Starting day:21/07/2009                                                     //
//////////////////////////////////////////////////////////////////////////////////////////
//Basic Includes************************************************************************//
#include <mygba.h>
#include "gba.h"
//***********************************************************************Basic Includes*//
#include "define.c"
#include "declare.c"
#include "struct.c"
#include "vars.c"
#include "audio.c"
#include "input.c"
#include "widget.c"
#include "text.c"
#include "init.c"
#include "tracker.c"
#include "sample.c"
#include "instruments.c"
#include "song.c"
#include "live.c"
#include "file.c"
#include "config.c"
int main(void)
{
//* S O N G _ I N I T I A L I Z A T I O N********************************************************************************

    init();
    load_song();
    
    while(TRUE)
    {
        MENUSWITCH=1;
        RESET=0;
        PAT_POS=0;
        MENU=3;   //<<----------
        CURSOR=0;
        LEVEL=0;
        KEYVALUE=0;
        PLAYING=0;
        TEMPO_TIMER=0;
        while(!RESET)
        {
            GetInput();
            GetInput_General();
            PlaySong();
            switch(MENU)
            {
                case 255:
                    MENU=0;
                    break;
                case 0:
                    if(!PLAYING)GetInput_Tracker();
                    Draw_Tracker();
                    Draw_Tracker_Cursor();
                    break;
                case 1:
                    Draw_Samples();
                    break;
                case 2:
                    //Draw_Inst();
                    break;
                case 3:
                    Draw_Song();
                    GetInput_Song();
                    break;
                case 4:
                    Draw_Live();
                    break;
                case 5:
                    Draw_File();
                    GetInput_File();
                    break;
                case 6:
                    Draw_Config();
                    GetInput_Config();
                    break;
                case 7:
                    MENU=6;
                    break;
            }
        MENUSWITCH=0;
        }
    }
    free(SONG);
    return 0;
}

