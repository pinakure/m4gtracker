void Draw_Config(void)
{
    TEMPO_FIX=4;
    //tab section*************************************************************
    tab(1,0,1);tab(5,0,1);tab(9,0,1);tab(13,0,1);tab(17,0,1);tab(21,0,1);tab(25,0,0);
    PutText( 1,0x01,"patt",1);
    PutText( 5,0x01,"samp",1);
    PutText( 9,0x01,"inst",1);
    PutText(13,0x01,"song",1);
    PutText(17,0x01,"live",1);
    PutText(21,0x01,"file",1);
    PutText(25,0x01,"CFG",0);
    //draw setup menu*************************************************************
    if(MENUSWITCH==1){ClearText(0);ClearText(2);}
    Window(0,2,18,19,1);
    Window(19,2,29,19,0);
    PutText( 2 ,3+CFGCUR,">",0);
    PutText( 5 ,3,"WRAP PATTERNS",1);
    PutText( 20,3,enabool(T_WRAP),1);
    PutText( 9 ,4,"VU-METERS",1);
    PutText( 20,4,enabool(VUMETERS),1);
    PutText( 11,5,"PALETTE",1);
    PutText( 20,5,getpalettename(PALETTE),1);
    PutText( 14,6,"SKIN",1);
    PutText( 20,6,getskinname(),1);
    PutText( 14,7,"FONT",1);
    PutText( 20,7,getfontname(),1);
    PutText( 13,8,"TEMPO",1);
    itoa(TEMPO,(char*)value);
    PutText( 20,8,(char*)value,1);
}




